/*
 * SPI_configuration.h
 *
 *  Created on: Apr 11, 2023
 *      Author: ss210
 */

#ifndef MCAL_SPI_SPI_CONFIGURATION_H_
#define MCAL_SPI_SPI_CONFIGURATION_H_



#endif /* MCAL_SPI_SPI_CONFIGURATION_H_ */
