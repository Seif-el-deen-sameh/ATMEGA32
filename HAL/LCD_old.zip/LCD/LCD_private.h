/*
 * LCD_private.h
 *
 *  Created on: Mar 28, 2023
 *      Author: ss210
 */

#ifndef HAL_LCD_LCD_PRIVATE_H_
#define HAL_LCD_LCD_PRIVATE_H_
#define LCD_data PORTA


#endif /* HAL_LCD_LCD_PRIVATE_H_ */
