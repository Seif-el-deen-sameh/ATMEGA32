/*
 * LCD_configuration.h
 *
 *  Created on: Mar 31, 2023
 *      Author: ss210
 */

#ifndef HAL_LCD_LCD_CONFIGURATION_H_
#define HAL_LCD_LCD_CONFIGURATION_H_



#endif /* HAL_LCD_LCD_CONFIGURATION_H_ */
