/*
 * LCD_interface.h
 *
 *  Created on: Mar 28, 2023
 *      Author: ss210
 */

#ifndef HAL_LCD_LCD_INTERFACE_H_
#define HAL_LCD_LCD_INTERFACE_H_
#include "std_types.h"
void LCD_init(void);
void LCD_init_4_bit(void);
void LCD_command(u8 c);
void LCD_command_4_bit(u8 c1);
void LCD_Char(u8 e);
void LCD_Char_4_bit(u8 e1);
void LCD_send_string(u8 arr[]);
void LCD_send_string_4_bit(u8 arr[]);
void LCD_clr(void);
void LCD_clr_4_bit(void);
void LCD_Char_new (u8 location, u8 *new_char);
void LCD_string(u8 *str);

#endif /* HAL_LCD_LCD_INTERFACE_H_ */
