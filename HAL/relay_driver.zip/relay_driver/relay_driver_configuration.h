/*
 * relay_driver_configuration.h
 *
 *  Created on: Apr 1, 2023
 *      Author: ss210
 */

#ifndef HAL_RELAY_DRIVER_RELAY_DRIVER_CONFIGURATION_H_
#define HAL_RELAY_DRIVER_RELAY_DRIVER_CONFIGURATION_H_



#endif /* HAL_RELAY_DRIVER_RELAY_DRIVER_CONFIGURATION_H_ */
