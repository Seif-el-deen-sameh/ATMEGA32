/*
 * button_configuration.h
 *
 *  Created on: Apr 1, 2023
 *      Author: ss210
 */

#ifndef HAL_BUTTON_BUTTON_CONFIGURATION_H_
#define HAL_BUTTON_BUTTON_CONFIGURATION_H_



#endif /* HAL_BUTTON_BUTTON_CONFIGURATION_H_ */
