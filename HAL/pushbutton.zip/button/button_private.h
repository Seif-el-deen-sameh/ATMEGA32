/*
 * button_private.h
 *
 *  Created on: Apr 1, 2023
 *      Author: ss210
 */

#ifndef HAL_BUTTON_BUTTON_PRIVATE_H_
#define HAL_BUTTON_BUTTON_PRIVATE_H_

#define BTN0          DIO_PIN0
#define BTN0_PRT      DIO_PORTB
#define BTN0_IN      DIO_INPUT

#endif /* HAL_BUTTON_BUTTON_PRIVATE_H_ */
