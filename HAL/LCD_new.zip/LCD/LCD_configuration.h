/*
 * LCD_configuration.h
 *
 *  Created on: Mar 31, 2023
 *      Author: ss210
 */

#ifndef HAL_LCD_LCD_CONFIGURATION_H_
#define HAL_LCD_LCD_CONFIGURATION_H_

#define mode _8_bit
#define _8_bit 1
#define _4_bit 2

#endif /* HAL_LCD_LCD_CONFIGURATION_H_ */
