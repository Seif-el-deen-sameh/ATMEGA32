/*
 * motor_driver_configuration.h
 *
 *  Created on: Apr 9, 2023
 *      Author: ss210
 */

#ifndef HAL_MOTOR_DRIVER_MOTOR_DRIVER_CONFIGURATION_H_
#define HAL_MOTOR_DRIVER_MOTOR_DRIVER_CONFIGURATION_H_



#endif /* HAL_MOTOR_DRIVER_MOTOR_DRIVER_CONFIGURATION_H_ */
